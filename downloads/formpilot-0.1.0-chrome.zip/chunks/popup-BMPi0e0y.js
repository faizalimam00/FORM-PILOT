import{j as t,k as e}from"./styles-B4Xuwyau.js";import{R as o}from"./Review-BGVJCQ6o.js";function r(){return t.jsx(o,{compact:!0})}e.createRoot(document.getElementById("root")).render(t.jsx(r,{}));
