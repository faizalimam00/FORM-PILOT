import{k as e,j as t}from"./styles-B4Xuwyau.js";import{R as o}from"./Review-BGVJCQ6o.js";e.createRoot(document.getElementById("root")).render(t.jsx(o,{}));
